import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MatchesScreen extends StatefulWidget {
  const MatchesScreen({super.key});

  @override
  State<MatchesScreen> createState() => _MatchesScreenState();
}

class _MatchesScreenState extends State<MatchesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Map<String, dynamic>> _peopleMatches = [];
  List<Map<String, dynamic>> _jobMatches = [];
  bool _loading = true;
  String? _userId;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadAll();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadAll() async {
    setState(() => _loading = true);

    _userId = Supabase.instance.client.auth.currentUser?.id;
    if (_userId == null) {
      setState(() => _loading = false);
      return;
    }

    await Future.wait([_loadPeopleMatches(), _loadJobMatches()]);
    setState(() => _loading = false);
  }

  Future<void> _loadPeopleMatches() async {
    try {
      final res = await Supabase.instance.client
          .from('matches')
          .select('id, journeyman_id, helper_id, created_at')
          .or('journeyman_id.eq.$_userId,helper_id.eq.$_userId')
          .order('created_at', ascending: false);

      final matches = (res as List).cast<Map<String, dynamic>>();
      List<Map<String, dynamic>> enriched = [];

      for (final match in matches) {
        final otherId = match['journeyman_id'] == _userId
            ? match['helper_id']
            : match['journeyman_id'];

        try {
          final userRes = await Supabase.instance.client
              .from('users')
              .select('id, email, role, profiles(full_name, location_text, experience_level, trade_type)')
              .eq('id', otherId)
              .maybeSingle();

          if (userRes != null) {
            enriched.add({
              'match_id': match['id'],
              'created_at': match['created_at'],
              'user': userRes,
            });
          }
        } catch (e) {
          // skip
        }
      }

      _peopleMatches = enriched;
    } catch (e) {
      _peopleMatches = [];
    }
  }

  Future<void> _loadJobMatches() async {
    try {
      // Get jobs the user liked
      final likedRes = await Supabase.instance.client
          .from('job_swipes')
          .select('job_id')
          .eq('user_id', _userId!)
          .eq('liked', true);

      final likedJobIds = (likedRes as List).map((s) => s['job_id']).toList();

      if (likedJobIds.isEmpty) {
        _jobMatches = [];
        return;
      }

      final jobsRes = await Supabase.instance.client
          .from('jobs')
          .select('id, title, description, location_text, hourly_rate, experience_required, duration_days, journeyman_id, users(profiles(full_name))')
          .inFilter('id', likedJobIds)
          .eq('is_active', true);

      _jobMatches = (jobsRes as List).cast<Map<String, dynamic>>();
    } catch (e) {
      _jobMatches = [];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MATCHES'),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: const Color(0xFFFF6B35),
          labelColor: const Color(0xFFFF6B35),
          unselectedLabelColor: const Color(0xFF8896b0),
          tabs: const [
            Tab(text: 'PEOPLE'),
            Tab(text: 'JOBS'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF8896b0)),
            onPressed: _loadAll,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFFF6B35)))
          : TabBarView(
              controller: _tabController,
              children: [
                _buildPeopleTab(),
                _buildJobsTab(),
              ],
            ),
    );
  }

  Widget _buildPeopleTab() {
    if (_peopleMatches.isEmpty) {
      return _buildEmpty('🤝', 'No people matches yet', 'Start swiping to find your crew');
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _peopleMatches.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final match = _peopleMatches[index];
        final user = match['user'] as Map<String, dynamic>;
        final profile = user['profiles'] as Map<String, dynamic>?;
        final name = profile?['full_name'] ?? user['email'] ?? 'Unknown';
        final location = profile?['location_text'] ?? '';
        final role = user['role'] ?? '';
        final experience = profile?['experience_level'] ?? '';
        final trade = profile?['trade_type'] ?? '';

        String expLabel = experience;
        switch (experience) {
          case 'apprentice_1st': expLabel = '1st Year'; break;
          case 'apprentice_2nd': expLabel = '2nd Year'; break;
          case 'apprentice_3rd': expLabel = '3rd Year'; break;
          case 'apprentice_4th': expLabel = '4th Year'; break;
          case 'journeyman': expLabel = 'Journeyman'; break;
          case 'master': expLabel = 'Master'; break;
        }

        return Container(
          decoration: BoxDecoration(
            color: const Color(0xFF111827),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF1e2d45)),
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.all(16),
            leading: Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: const Color(0xFF1E3A5F),
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFFFF6B35), width: 2),
              ),
              child: const Icon(Icons.person, color: Color(0xFFFF6B35), size: 28),
            ),
            title: Text(
              name,
              style: const TextStyle(color: Color(0xFFF0F4FF), fontWeight: FontWeight.w600, fontSize: 16),
            ),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Row(
                  children: [
                    _chip(role.toUpperCase(), role == 'journeyman' ? const Color(0xFF1E3A5F) : const Color(0xFFFF6B35).withOpacity(0.2),
                        role == 'journeyman' ? const Color(0xFF7eb3ff) : const Color(0xFFFF6B35)),
                    if (expLabel.isNotEmpty) ...[
                      const SizedBox(width: 4),
                      _chip(expLabel, const Color(0xFF1a2235), const Color(0xFF8896b0)),
                    ],
                  ],
                ),
                if (location.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.location_on, color: Color(0xFF8896b0), size: 12),
                      const SizedBox(width: 2),
                      Text(location, style: const TextStyle(color: Color(0xFF8896b0), fontSize: 12)),
                    ],
                  ),
                ],
              ],
            ),
            trailing: GestureDetector(
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Chat coming soon!'), backgroundColor: Color(0xFF111827)),
                );
              },
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: const Color(0xFFFF6B35).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.chat_bubble_outline, color: Color(0xFFFF6B35), size: 20),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildJobsTab() {
    if (_jobMatches.isEmpty) {
      return _buildEmpty('📋', 'No job matches yet', 'Swipe right on jobs you like');
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: _jobMatches.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (context, index) {
        final job = _jobMatches[index];
        final title = job['title'] ?? 'Untitled Job';
        final location = job['location_text'] ?? '';
        final rate = job['hourly_rate'];
        final duration = job['duration_days'];
        final poster = job['users']?['profiles']?['full_name'] ?? 'Unknown';
        final experience = job['experience_required'] ?? 'any';

        String expLabel = experience;
        switch (experience) {
          case 'any': expLabel = 'Any Level'; break;
          case 'apprentice': expLabel = 'Apprentice'; break;
          case 'journeyman': expLabel = 'Journeyman'; break;
          case 'master': expLabel = 'Master'; break;
        }

        return Container(
          decoration: BoxDecoration(
            color: const Color(0xFF111827),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: const Color(0xFF1e2d45)),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E3A5F),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFFFF6B35), width: 1.5),
                      ),
                      child: const Icon(Icons.work, color: Color(0xFFFF6B35), size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(title, style: const TextStyle(color: Color(0xFFF0F4FF), fontSize: 15, fontWeight: FontWeight.w700)),
                          Text('Posted by $poster', style: const TextStyle(color: Color(0xFF8896b0), fontSize: 12)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    if (location.isNotEmpty) _chip('📍 $location', const Color(0xFF1a2235), const Color(0xFF8896b0)),
                    if (rate != null) _chip('\$$rate/hr', const Color(0xFF22c55e).withOpacity(0.15), const Color(0xFF22c55e)),
                    if (duration != null) _chip('$duration days', const Color(0xFF1a2235), const Color(0xFF8896b0)),
                    _chip(expLabel, const Color(0xFF1E3A5F), const Color(0xFF7eb3ff)),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  job['description'] ?? '',
                  style: const TextStyle(color: Color(0xFF8896b0), fontSize: 13),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildEmpty(String emoji, String title, String subtitle) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(emoji, style: const TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          Text(title, style: const TextStyle(color: Color(0xFFF0F4FF), fontSize: 20, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text(subtitle, style: const TextStyle(color: Color(0xFF8896b0))),
        ],
      ),
    );
  }

  Widget _chip(String label, Color bg, Color fg) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(4)),
      child: Text(label, style: TextStyle(color: fg, fontSize: 10, fontWeight: FontWeight.w700)),
    );
  }
}