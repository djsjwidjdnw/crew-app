import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:appinio_swiper/appinio_swiper.dart';

class SwipeScreen extends StatefulWidget {
  const SwipeScreen({super.key});

  @override
  State<SwipeScreen> createState() => _SwipeScreenState();
}

class _SwipeScreenState extends State<SwipeScreen> {
  final AppinioSwiperController _swiperController = AppinioSwiperController();
  List<Map<String, dynamic>> _cards = [];
  bool _loading = true;
  String? _userRole;
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        setState(() {
          _loading = false;
          _error = 'Not logged in';
        });
        return;
      }

      final userRes = await Supabase.instance.client
          .from('users')
          .select('role')
          .eq('id', userId)
          .maybeSingle();

      _userRole = userRes?['role'] ?? 'helper';

      final swipedRes = await Supabase.instance.client
          .from('swipes')
          .select('swiped_id')
          .eq('swiper_id', userId);

      final swipedIds = (swipedRes as List).map((s) => s['swiped_id']).toList();

      final oppositeRole = _userRole == 'journeyman' ? 'helper' : 'journeyman';

      final profilesRes = await Supabase.instance.client
          .from('users')
          .select('id, email, role, profiles(full_name, bio, location_text, experience_level, profile_photo_url)')
          .eq('role', oppositeRole)
          .neq('id', userId)
          .limit(20);

      setState(() {
        _cards = (profilesRes as List)
            .where((p) => !swipedIds.contains(p['id']))
            .toList()
            .cast<Map<String, dynamic>>();
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = 'Failed to load profiles. Tap refresh to try again.';
      });
    }
  }

  Future<void> _recordSwipe(String swipedId, bool liked) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    try {
      await Supabase.instance.client.from('swipes').insert({
        'swiper_id': userId,
        'swiped_id': swipedId,
        'liked': liked,
      });
    } catch (e) {
      // Silently fail on swipe record
    }
  }

  @override
  void dispose() {
    _swiperController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CREW'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: Color(0xFF8896b0)),
            onPressed: _loadData,
          ),
        ],
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: Color(0xFFFF6B35)),
            )
          : _error != null
              ? _buildError()
              : _cards.isEmpty
                  ? _buildEmpty()
                  : _buildSwiper(),
    );
  }

  Widget _buildError() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('⚠️', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          Text(
            _error!,
            style: const TextStyle(color: Color(0xFF8896b0)),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: _loadData, child: const Text('TRY AGAIN')),
        ],
      ),
    );
  }

  Widget _buildEmpty() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text('🔧', style: TextStyle(fontSize: 48)),
          const SizedBox(height: 16),
          const Text(
            'No profiles yet',
            style: TextStyle(
              color: Color(0xFFF0F4FF),
              fontSize: 20,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Check back when more users join',
            style: TextStyle(color: Color(0xFF8896b0)),
          ),
          const SizedBox(height: 24),
          ElevatedButton(onPressed: _loadData, child: const Text('REFRESH')),
        ],
      ),
    );
  }

  Widget _buildSwiper() {
    return Column(
      children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: AppinioSwiper(
              controller: _swiperController,
              cardCount: _cards.length,
              onSwipeEnd: (previousIndex, targetIndex, activity) {
                final card = _cards[previousIndex];
                final liked = activity.direction == AxisDirection.right;
                _recordSwipe(card['id'], liked);
              },
              cardBuilder: (context, index) {
                return _buildCard(_cards[index]);
              },
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 32, left: 48, right: 48),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () => _swiperController.swipeLeft(),
                child: Container(
                  width: 64,
                  height: 64,
                  decoration: BoxDecoration(
                    color: const Color(0xFF111827),
                    shape: BoxShape.circle,
                    border: Border.all(color: const Color(0xFFef4444), width: 2),
                  ),
                  child: const Icon(Icons.close, color: Color(0xFFef4444), size: 32),
                ),
              ),
              GestureDetector(
                onTap: () => _swiperController.swipeRight(),
                child: Container(
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: const Color(0xFFFF6B35),
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFFF6B35).withOpacity(0.4),
                        blurRadius: 16,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.check, color: Colors.white, size: 36),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCard(Map<String, dynamic> user) {
    final profile = user['profiles'] as Map<String, dynamic>?;
    final name = profile?['full_name'] ?? user['email'] ?? 'Unknown';
    final bio = profile?['bio'] ?? 'No bio yet';
    final location = profile?['location_text'] ?? 'Alberta, CA';
    final experience = profile?['experience_level'] ?? 'N/A';
    final role = user['role'] ?? '';

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF111827),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF1e2d45)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 3,
            child: Container(
              decoration: const BoxDecoration(
                color: Color(0xFF1a2235),
                borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
              ),
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E3A5F),
                        shape: BoxShape.circle,
                        border: Border.all(color: const Color(0xFFFF6B35), width: 2),
                      ),
                      child: const Icon(Icons.person, color: Color(0xFFFF6B35), size: 52),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      name,
                      style: const TextStyle(
                        color: Color(0xFFF0F4FF),
                        fontSize: 24,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: role == 'journeyman'
                            ? const Color(0xFF1E3A5F)
                            : const Color(0xFFFF6B35).withOpacity(0.2),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: TextStyle(
                          color: role == 'journeyman'
                              ? const Color(0xFF7eb3ff)
                              : const Color(0xFFFF6B35),
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            flex: 2,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.location_on, color: Color(0xFF8896b0), size: 16),
                      const SizedBox(width: 4),
                      Text(location, style: const TextStyle(color: Color(0xFF8896b0), fontSize: 13)),
                      const Spacer(),
                      const Icon(Icons.work, color: Color(0xFF8896b0), size: 16),
                      const SizedBox(width: 4),
                      Text(experience, style: const TextStyle(color: Color(0xFF8896b0), fontSize: 13)),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    bio,
                    style: const TextStyle(color: Color(0xFFF0F4FF), fontSize: 14, height: 1.5),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}