import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  Map<String, dynamic>? _user;
  bool _loading = true;
  bool _saving = false;
  String? _error;

  final _nameController = TextEditingController();
  final _bioController = TextEditingController();
  final _locationController = TextEditingController();
  final _experienceController = TextEditingController();
  final _phoneController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) {
        setState(() { _loading = false; });
        return;
      }

      final userRes = await Supabase.instance.client
          .from('users')
          .select('id, email, role')
          .eq('id', userId)
          .maybeSingle();

      final profileRes = await Supabase.instance.client
          .from('profiles')
          .select('full_name, bio, location_text, experience_level, phone')
          .eq('user_id', userId)
          .maybeSingle();

      setState(() {
        _user = userRes;
        _nameController.text = profileRes?['full_name'] ?? '';
        _bioController.text = profileRes?['bio'] ?? '';
        _locationController.text = profileRes?['location_text'] ?? '';
        _experienceController.text = profileRes?['experience_level'] ?? '';
        _phoneController.text = profileRes?['phone'] ?? '';
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _loading = false;
        _error = 'Failed to load profile.';
      });
    }
  }

  Future<void> _saveProfile() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;

    setState(() => _saving = true);

    try {
      await Supabase.instance.client.from('profiles').upsert({
        'user_id': userId,
        'full_name': _nameController.text.trim(),
        'bio': _bioController.text.trim(),
        'location_text': _locationController.text.trim(),
        'experience_level': _experienceController.text.trim(),
        'phone': _phoneController.text.trim(),
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile saved!'), backgroundColor: Color(0xFF22c55e)),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Error saving profile'), backgroundColor: Color(0xFFef4444)),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _signOut() async {
    await Supabase.instance.client.auth.signOut();
    if (mounted) Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  void dispose() {
    _nameController.dispose();
    _bioController.dispose();
    _locationController.dispose();
    _experienceController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('PROFILE'),
        actions: [
          TextButton(
            onPressed: _signOut,
            child: const Text('SIGN OUT', style: TextStyle(color: Color(0xFFef4444), fontSize: 12)),
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: Color(0xFFFF6B35)))
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(_error!, style: const TextStyle(color: Color(0xFF8896b0))),
                      const SizedBox(height: 16),
                      ElevatedButton(onPressed: _loadProfile, child: const Text('RETRY')),
                    ],
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Avatar
                      Center(
                        child: Column(
                          children: [
                            Container(
                              width: 90,
                              height: 90,
                              decoration: BoxDecoration(
                                color: const Color(0xFF1E3A5F),
                                shape: BoxShape.circle,
                                border: Border.all(color: const Color(0xFFFF6B35), width: 2),
                              ),
                              child: const Icon(Icons.person, color: Color(0xFFFF6B35), size: 48),
                            ),
                            const SizedBox(height: 12),
                            Text(
                              _user?['email'] ?? '',
                              style: const TextStyle(color: Color(0xFF8896b0), fontSize: 13),
                            ),
                            const SizedBox(height: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                              decoration: BoxDecoration(
                                color: _user?['role'] == 'journeyman'
                                    ? const Color(0xFF1E3A5F)
                                    : const Color(0xFFFF6B35).withOpacity(0.2),
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: Text(
                                (_user?['role'] ?? '').toUpperCase(),
                                style: TextStyle(
                                  color: _user?['role'] == 'journeyman'
                                      ? const Color(0xFF7eb3ff)
                                      : const Color(0xFFFF6B35),
                                  fontSize: 11,
                                  fontWeight: FontWeight.w700,
                                  letterSpacing: 2,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 36),

                      _buildLabel('FULL NAME'),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _nameController,
                        style: const TextStyle(color: Color(0xFFF0F4FF)),
                        decoration: const InputDecoration(hintText: 'John Smith'),
                      ),

                      const SizedBox(height: 20),

                      _buildLabel('PHONE'),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        style: const TextStyle(color: Color(0xFFF0F4FF)),
                        decoration: const InputDecoration(hintText: '780-555-0123'),
                      ),

                      const SizedBox(height: 20),

                      _buildLabel('LOCATION'),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _locationController,
                        style: const TextStyle(color: Color(0xFFF0F4FF)),
                        decoration: const InputDecoration(hintText: 'Rocky Mountain House, AB'),
                      ),

                      const SizedBox(height: 20),

                      _buildLabel('EXPERIENCE LEVEL'),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _experienceController,
                        style: const TextStyle(color: Color(0xFFF0F4FF)),
                        decoration: const InputDecoration(hintText: 'e.g. Journeyman, Apprentice, 5 years'),
                      ),

                      const SizedBox(height: 20),

                      _buildLabel('BIO'),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _bioController,
                        style: const TextStyle(color: Color(0xFFF0F4FF)),
                        maxLines: 4,
                        decoration: const InputDecoration(
                          hintText: 'Tell people about yourself...',
                          alignLabelWithHint: true,
                        ),
                      ),

                      const SizedBox(height: 32),

                      ElevatedButton(
                        onPressed: _saving ? null : _saveProfile,
                        child: _saving
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                              )
                            : const Text('SAVE PROFILE'),
                      ),

                      const SizedBox(height: 32),
                    ],
                  ),
                ),
    );
  }

  Widget _buildLabel(String text) {
    return Text(
      text,
      style: const TextStyle(color: Color(0xFF8896b0), fontSize: 11, letterSpacing: 2),
    );
  }
}